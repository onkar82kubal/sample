from datetime import datetime
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_serializer

from usermanagement.schemas.common import PyObjectId, CleanStr
from usermanagement.utils.date import datetime_to_iso8601_with_z_suffix

class PermissionModel(BaseModel):
    # id: PyObjectId = Field(default_factory=PyObjectId, alias="_id")
    permission_name: CleanStr
    permission_key: CleanStr
    created: datetime = Field(default_factory=datetime.utcnow)
    updated: datetime | None = None
    isactive : bool

    model_config = ConfigDict(
        populate_by_name=True, 
        arbitrary_types_allowed=True,
        from_attributes=True
    )

    @field_serializer("created")
    def serialize_created(self, created: datetime | None, _info) -> str | None:
        """Serialize the created field."""
        if created is None:
            return None
        return datetime_to_iso8601_with_z_suffix(created)

    @field_serializer("updated")
    def serialize_updated(self, updated: datetime | None, _info) -> str | None:
        """Serialize the updated field."""
        if updated is None:
            return None
        return datetime_to_iso8601_with_z_suffix(updated)