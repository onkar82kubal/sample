from datetime import datetime
from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_serializer

from usermanagement.schemas.common import PyObjectId, CleanStr
from usermanagement.utils.date import datetime_to_iso8601_with_z_suffix


class Token(BaseModel):
    access_token: str
    token_type: str