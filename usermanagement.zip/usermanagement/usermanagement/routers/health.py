import daiquiri
from fastapi import APIRouter

LOGGER = daiquiri.getLogger(__name__)
router = APIRouter(
    prefix="/health",
    tags=["health"],
)


@router.get("/")
def health():
    return {'message':'Working Fine'}
