from typing import Annotated, List
from usermanagement.utils.date import now
from usermanagement.schemas.group import GroupModel
import daiquiri
from fastapi import (
    APIRouter,
    Body,
    Depends,
    HTTPException,
    Query,
    Request,
    Response,
    status,
)
from bson import ObjectId
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from starlette.status import (
    HTTP_201_CREATED,
    HTTP_204_NO_CONTENT,
    HTTP_304_NOT_MODIFIED,
    HTTP_404_NOT_FOUND,
    HTTP_500_INTERNAL_SERVER_ERROR,
)
from usermanagement.settings import SETTINGS

router = APIRouter(
    prefix="/group",
    tags=["Groups"],
)

LOGGER = daiquiri.getLogger(__name__)
COLLECTION = "groups"