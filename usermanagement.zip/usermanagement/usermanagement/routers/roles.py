from typing import Annotated, List
from usermanagement.utils.date import now
from usermanagement.schemas.role import RoleModel
import daiquiri
from fastapi import (
    APIRouter,
    Body,
    Depends,
    HTTPException,
    Query,
    Request,
    Response,
    status,
)
from bson import ObjectId
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from starlette.status import (
    HTTP_201_CREATED,
    HTTP_204_NO_CONTENT,
    HTTP_304_NOT_MODIFIED,
    HTTP_404_NOT_FOUND,
    HTTP_500_INTERNAL_SERVER_ERROR,
)
from usermanagement.settings import SETTINGS

router = APIRouter(
    prefix="/role",
    tags=["Roles"],
)

LOGGER = daiquiri.getLogger(__name__)
COLLECTION = "roles"

@router.get("", include_in_schema=False)
@router.get("/")
async def list_roles(
    request: Request,
    limit: int | None = Query(default=10),
    offset: int | None = Query(default=0),
) -> List[RoleModel]:
    """ List existing template"""
    try:
        collection = request.app.mongodb_client[SETTINGS.mongodb_name][COLLECTION]
        roles: list[RoleModel] = []
        async for user in collection.find({}).skip(offset).limit(limit):
            roles.append(RoleModel(**user))
        return roles
    except Exception as err:
        LOGGER.error(
            "There was a problem while fetching items. Error: %s",
            err,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(err),
        )
    
@router.post("/")
@router.post("", include_in_schema=False)
async def add_role(
    request: Request,
    item: Annotated[RoleModel, Body(...)],
    ) -> RoleModel:
    """ Save Users"""
    try:
        collection = request.app.mongodb_client[SETTINGS.mongodb_name][COLLECTION]
        new_entry = await collection.insert_one(jsonable_encoder(item, exclude_none=True))
        created_entry = await collection.find_one({"_id": new_entry.inserted_id})
        created_entry['_id'] = str(created_entry['_id'])
        return JSONResponse(
            status_code=HTTP_201_CREATED, content=created_entry
        )
    except Exception as err:
        LOGGER.error(
            "There was a problem while adding item. Error: %s",
            err,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(err),
        )
    
@router.patch("/{item_id}/")
@router.patch("/{item_id}", include_in_schema=False)
async def update_asset_type(
    request: Request,
    item_id: str,
    item: Annotated[RoleModel, Body(...)],
) -> RoleModel:
    """Update an asset type."""
    try:
        stored_item_data = await request.app.mongodb[COLLECTION].find_one(
            {"_id": ObjectId(item_id)}
        )
        if not stored_item_data:
            raise HTTPException(
                status_code=HTTP_404_NOT_FOUND,
                detail=f"Asset type with id '{item_id}' was not found",
            )
        stored_item_model = RoleModel(**stored_item_data)

        update_data = item.dict(exclude_unset=True)
        updated_item = stored_item_model.copy(update=update_data)

        updated_item.updated = now()

        update_result = await request.app.mongodb[COLLECTION].update_one(
            {"_id": ObjectId(item_id)},
            {"$set": jsonable_encoder(updated_item, exclude={"id"})},
        )

        return JSONResponse(
            status_code=HTTP_204_NO_CONTENT, content=update_result
        )

    except Exception as err:
        if isinstance(err, HTTPException):
            raise err

        LOGGER.error(
            "There was a problem while listing items. Error: %s",
            err,
            exc_info=SETTINGS.debug,
        )
        raise HTTPException(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(err),
        )