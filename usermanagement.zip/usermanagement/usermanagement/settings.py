import json
import daiquiri
from pydantic import Field, ValidationInfo, field_validator
from pydantic_settings import BaseSettings

from usermanagement import __version__

LOGGER = daiquiri.getLogger(__name__)


class Settings(BaseSettings):
    """Settings."""

    app: str = "UserManagement"
    environment: str = "local"
    workers: int = 1
    version: str = __version__
    docs_url: str = "/api/usermanagement/docs"
    openapi_url: str = "/api/usermanagement/openapi.json"
    api_port: int = 9090
    log_level: str = "INFO"
    debug: bool = False
    allow_origins: list[str] = ["*"]
    allow_credentials: bool = True
    allow_methods: list[str] = ["*"]
    allow_headers: list[str] = ["*"]
    mongodb_url: str | None = None
    mongodb_name: str = "usermanagement"
    SECRET_KEY:str = "83daa0256a2289b0fb23693bf1f6034d44396675749244721a2b20e896e11662"
    ALGORITHM:str =  "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES:int = 30
    
    @field_validator("mongodb_url")
    def get_mongodb_url(cls, value, info: ValidationInfo):
        """Get MongoDB URL."""
        mongodb_url = value
        if mongodb_url is None:
            raise ValueError("Missing MongoDB URL.")
        return mongodb_url


    @field_validator("allow_origins")
    def add_additional_allow_origins(
        cls, value: list[str], info: ValidationInfo
    ):
        """Add additional allow_origins."""
        if info.data.get("environment") == "local":
            return value + ["http://localhost", "http://localhost:4200"]
        return value

    @field_validator("debug")
    def set_debug(cls, value, info: ValidationInfo):
        """Set debug when local or dev."""
        if info.data.get("environment") in ["local", "dev"]:
            return True
        return value


SETTINGS = Settings()
