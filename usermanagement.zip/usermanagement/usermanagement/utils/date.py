from datetime import datetime, timezone

import daiquiri
from dateutil.parser import parse

LOGGER = daiquiri.getLogger(__name__)


def datetime_to_iso8601_with_z_suffix(value: datetime) -> str:
    """Convert datetime to ISO 8601 with Z suffix"""
    if value.tzinfo is None:
        value = value.replace(tzinfo=timezone.utc)
    formatted_datetime: str = value.isoformat()
    if formatted_datetime.endswith("+00:00"):
        formatted_datetime = formatted_datetime[:-6] + "Z"
    return formatted_datetime


def now() -> datetime:
    """Get current datetime"""
    return datetime.now(timezone.utc)


def now_str() -> str:
    """Get current datetime as string"""
    return datetime_to_iso8601_with_z_suffix(now())


def str_to_datetime(value: str) -> str:
    """Convert string to datetime"""
    return datetime_to_iso8601_with_z_suffix(parse(value))