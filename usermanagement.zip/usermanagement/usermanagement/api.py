from contextlib import asynccontextmanager
import daiquiri
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING
from Secweb.xXSSProtection import xXSSProtection
from starlette_exporter import PrometheusMiddleware, handle_metrics

from usermanagement.middleware.logging import LoggingMiddleware
from usermanagement.routers import health,users, roles,permissions
from usermanagement.settings import SETTINGS

LOGGER = daiquiri.getLogger(__name__)


async def startup_db_client(application):
    application.mongodb_client = AsyncIOMotorClient(SETTINGS.mongodb_url)
    application.mongodb = application.mongodb_client[SETTINGS.mongodb_name]

    index_details = {
        "keys": [("name", ASCENDING)],
        "name": "name_unique",
        "unique": True,
        "background": True,
    }
    try:
        keys = index_details.pop("keys")
        await application.mongodb["users"].create_index(
            keys, **index_details
        )
    except Exception as err:
        LOGGER.warning(
            "There was a problem creating index '%s' for '%s'. %s",
            index_details,
            "users",
            err,
        )


async def shutdown_db_client(application):
    application.mongodb_client.close()


@asynccontextmanager
async def lifespan(application: FastAPI):
    """Defines the startup and shutdown events."""
    # Startup event
    await startup_db_client(application)

    yield

    # Shutdown event
    await shutdown_db_client(application)


app = FastAPI(
    title=SETTINGS.app,
    docs_url=SETTINGS.docs_url,
    openapi_url=SETTINGS.openapi_url,
    lifespan=lifespan,
)

# Routers 
app.include_router(health.router)
app.include_router(users.router)
app.include_router(roles.router)
app.include_router(permissions.router)

# Middlewares
app.add_middleware(
    CORSMiddleware,
    allow_origins=SETTINGS.allow_origins,
    allow_credentials=SETTINGS.allow_credentials,
    allow_methods=SETTINGS.allow_methods,
    allow_headers=SETTINGS.allow_headers,
)
# XSS Protection
# app.add_middleware(xXSSProtection)

#  For parameters supported by the PrometheusMiddleware,
#  Refer: https://github.com/stephenhillier/starlette_exporter#options
app.add_middleware(
    PrometheusMiddleware,
    app_name=SETTINGS.app,
    prefix="oncar",
    labels={"service_version": SETTINGS.version},
    group_paths=True,
    skip_paths=[
        "/",
        "/favicon.ico",
        SETTINGS.docs_url,
        SETTINGS.openapi_url,
    ],
)
app.add_middleware(LoggingMiddleware)
daiquiri.setup(level=SETTINGS.log_level)  # type: ignore
logging.getLogger("httpx").setLevel("WARNING")
logging.getLogger("httpcore").setLevel("WARNING")
logging.getLogger("aiormq").setLevel("WARNING")
logging.getLogger("aio_pika").setLevel("WARNING")


@app.get("/")
def read_root():
    return {
        "app": SETTINGS.app,
        "version": SETTINGS.version,
        "docs": SETTINGS.docs_url,
        "environment": SETTINGS.environment,
    }
