from starlette_exporter import multiprocess


def child_exit(server, worker):
    multiprocess.mark_process_dead(worker.pid)