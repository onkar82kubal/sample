from fastapi.testclient import TestClient
from usermanagement.api import app

client = TestClient(app)


def test_read_main():
    response = client.get("/health/")
    assert response.status_code == 200
    assert response.json() == { "message": "Working Fine"}


def test_list_users():
    response = client.get("/user/?limit=10&offset=0")
    assert response.status_code == 200
    # assert response.json() == []