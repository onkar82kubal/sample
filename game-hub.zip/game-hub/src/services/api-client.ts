import axios from "axios";

export default axios.create({
    baseURL: 'https://api.rawg.io/api',
    params: {
        key:'505901ce6b4d47b29a683c69c9734e3d'
    }
})