const categories = ["Utilities", "Movies", "Groceries"] as const;

export default categories